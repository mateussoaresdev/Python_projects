def add():
    print("INSERT INTO ....")
    print("Sucesso ao adicionar o usuário")
