def init():
    print("O banco está inicializado e conectado")
