def is_valid():
    print("Usuário Válido")
    return True
