def filter():
    print("Mostrando as vagas para Programador")
